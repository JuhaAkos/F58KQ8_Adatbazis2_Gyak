package pack;

public class ErKapcsolo {
	private int eid;
	private int mid;
	
	//konstruktor
	public ErKapcsolo(int eid, int mid) {
		super();
		this.eid = eid;
		this.mid = mid;
	}

	//getters,setters
	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}	
}
